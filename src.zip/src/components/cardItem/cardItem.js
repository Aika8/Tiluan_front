import React, {Component} from 'react';
import { ThreeDotsVertical } from 'react-bootstrap-icons';
import EService from '../../service';
import Spinner from '../spinner';

export default class CardItem extends Component{
    service = new EService();

    state = {
         id: this.props.card.id,
         name: this.props.card.name,
         addedDate: this.props.card.addedDate,
         tasks: this.props.card.tasks,
         taskDate: "",
         taskName: ""
    }
  

    addCardFunc = () =>{
        const {cardId, taskDate, taskName,tasks, ...card} = this.state;
        const task = {
            id: null, 
            description: this.state.taskName,
            addedDate: this.state.taskDate,
            card: card
        }
        this.service.addTask(task).then(() =>{
            this.LoadData() 
        });
        this.setState(() => ({taskName: "", taskDate: ""}));
        this.props.handleTaskClosed();

    }

    LoadData = () =>{
        this.service.getCard(this.state.id).then((card)=>{
            this.setState({
                id: card.data.id,
                name: card.data.name,
                addedDate: card.data.addedDate,
                tasks: card.data.tasks
            })
        })
    }
    
    
    onCardSubmit = (e) =>{
       
        var date = new Date();
        this.setState({taskDate: new Intl.DateTimeFormat("en-GB", {dateStyle: 'full', timeStyle: 'medium'}).format(date)}, this.addCardFunc);
    
        e.preventDefault();
    };


    onChangeCardName = (e) =>{
        this.setState({
            taskName :e.target.value
        });
    };

    

    render(){

        const {tasks} = this.state;
        
        if(!tasks){
            return <Spinner/>;
        }

        const tasksHtml = tasks.map((task) => {
  
            const {id, description} = task;
            return (
                
                <li key ={id}>{description}</li>
               
            );
        });

        let cardAddWindow
        if(this.props.cardId !== this.state.id){
            cardAddWindow = <button class="add-card-btn btn" onClick = {this.props.handleTaskWindow}>Add a card</button>
        }else{
            cardAddWindow = 
            <div class="add-card-btn btn">
            <form onSubmit={this.onCardSubmit}>
                    <div class="">
                        <input type="text" 
                            value={this.state.TaskName}
                            onChange={this.onChangeCardName}
                            required
                            className="mt-2"/>
                    </div>
    
                    <button class="submit btn" aria-label="Star Board">
                            Add
                    </button>
                    <button class="btn" aria-label="Star Board" onClick={this.props.handleTaskClosed}>
                            Cancel
                    </button>
                    </form>
                </div>
        }

        return(
            <>
               	<div class="list">
		
                <h3 class="list-title">{this.state.name}</h3>

                <ul class="list-items">
                    {tasksHtml}
                </ul>

                {cardAddWindow}

            </div> 
            </>
        );
    };
};