import BoardItem from './boardItem';
export default BoardItem;