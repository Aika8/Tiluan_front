import Register from './register';
export default Register;