import Board from './board';
export default Board;
