import Welcome from './welcome';
export default Welcome;