import Profile from './profile';
export default Profile;