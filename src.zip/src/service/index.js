import EService from './service';
export const userInstance = {
    isLoggedIn : '',
    user : ''
};
export default EService;